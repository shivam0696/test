<?php
session_start();
include('dbcon.php');
require 'vendor/autoload.php';  // Add this line to include PHPMailer

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

function sendemail_verify($name, $email, $verify_token) {
    $mail = new PHPMailer(true);
    
    try {
        $mail->isSMTP(); 
        $mail->SMTPAuth = true;
        $mail->Host = 'smtp.gmail.com';
        $mail->Username   = '06.viveksingh96@gmail.com';
        $mail->Password   = 'xnjzpdsspeqoafcn';
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        //Recipients
        $mail->setFrom('06.viveksingh96@gmail.com', $name);
        $mail->addAddress($email);

        //Content
        $mail->isHTML(true);  
        $mail->Subject = 'Email Verification';

        $email_template= "
        <h2>You have Registered With Vivek</h2>
        <h5>Verify Your Email Address To Login With The Below Given Link</h5>
        <br/><br/>
        <a href='http://localhost/login/verify-email.php?token=$verify_token'>Click Here</a>
        ";

        $mail->Body = $email_template;
        $mail->send();
        // echo 'Message has been sent';
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}

if (isset($_POST['register_btn'])) {
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $verify_token = md5(rand());



    // Check Duplicate Email 
    $check_email_query = "SELECT email FROM users WHERE email='$email' LIMIT 1";
    $check_email_query_run = mysqli_query($con, $check_email_query);

    if (mysqli_num_rows($check_email_query_run) > 0) {
        $_SESSION['status'] = "Email Id already Exists";
        header("Location: register.php");
    } else {
        // Insert Data
        $query = "INSERT INTO users (name, phone, email, password, verify_token) VALUES ('$name', '$phone', '$email', '$password', '$verify_token')";
        $query_run = mysqli_query($con, $query);

        if ($query_run) {
            sendemail_verify($name, $email, $verify_token);
            $_SESSION['status'] = "Registration Successful : Please Verify Your Email Address";
            header("Location: register.php");
        } else {
            $_SESSION['status'] = "Registration Failed";
            header("Location: register.php");
        }
    }
}
?>
