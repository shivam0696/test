<?php
session_start();
unset( $_SESSION['authentication']);
unset( $_SESSION['auth_user']);

$_SESSION['status']="You ARE logout successfully!!";

header("Location: login.php");
exit(0)


?>