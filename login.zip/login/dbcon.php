<?php

$con=mysqli_connect('localhost', 'root', '','login');

if(!$con){
    echo "Connection Failed!";
}


?>