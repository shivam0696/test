<?php 

$page_title="Home Page";
include('includes/header.php'); 
include('includes/navbar.php'); 
?>
<div class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <h2>Login with Email Varification in Php</h2>
            </div>
        </div>
    </div>
</div>

<?php include('includes/footer.php'); ?>