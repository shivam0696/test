<?php
session_start();
if(!isset($_SESSION['authentication']))
{
    $_SESSION['status'] = "Plese Login to Access User Dashboard!";
    header("Location: login.php");
    exit(0);

}



?>




