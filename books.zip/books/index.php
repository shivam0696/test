<?php 
session_start();
$page_title="Manage Book List";
include('includes/header.php'); 
include("db.php");
include("function.php");

?>
<style>
.is-invalid {
    border-color: #dc3545;
}

.invalid-feedback {
    color: #dc3545;
    display: none;
}

.is-invalid ~ .invalid-feedback {
    display: block;
}
</style>
<!-- Insert Book data Modal-->
<div class="modal fade" id="insertBook" tabindex="-1" aria-labelledby="insertBookLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="insertBookLabel">Add Book Details :</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
    <form action="code.php" method="POST">
      <div class="modal-body">

        <div class="form-group mb-3">
            <label for="">Book Title <span style="color:#F00;">*</span></label>
            <input type="text" name="title" class="form-control" placeholder="Enter book title" onKeyUp="this.value = this.value.toUpperCase()" autocomplete="off" maxlength="35" >
        </div>

        <div class="form-group mb-3">
            <label for="">Author <span style="color:#F00;">*</span></label>
            <input type="text" name="author" class="form-control" placeholder="Enter book author" onKeyUp="this.value = this.value.toUpperCase()" autocomplete="off" maxlength="30">
        </div>

        <div class="form-group mb-3">
            <label for="">Genre</label>
            <input type="text" name="genre" class="form-control" placeholder="Enter book genre" onKeyUp="this.value = this.value.toUpperCase()" autocomplete="off" maxlength="30">
        </div>

        <div class="form-group mb-3">
          <label class="year">Publication Year <span style="color:#F00;">Please enter a valid year between 1500 and the current year.</span></label>
          <input type="number" name="publication_year" class="form-control"
          placeholder="Enter publication year" min="1500" max="2099" required>
        </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
        <button type="submit" name="save_book" class="btn btn-success">Save</button>
      </div>
      </form>
    </div>
  </div>
</div>
<!-- Insert  Book data Modal-->


<!-- View Book data Modal -->
<div class="modal fade" id="view_book_modal" tabindex="-1" aria-labelledby="view_book_modalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="view_book_modalLabel">View Book Details :</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="view_book_data">

        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!-- View Book data Modal -->


<!-- Update Book data Modal-->
<div class="modal fade" id="update_book_modal" tabindex="-1" aria-labelledby="update_book_modal" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="update_book_modal">Update Book Details :</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
    <form action="code.php" method="POST">
      <div class="modal-body">
      <div class="form-group mb-3">
            <input type="hidden" name="id" class="form-control" id="id">
        </div>

        <div class="form-group mb-3">
            <label for="">Book Title <span style="color:#F00;">*</span></label>
            <input type="text" name="title" class="form-control" id="title" placeholder="Enter book title" onKeyUp="this.value = this.value.toUpperCase()" autocomplete="off" maxlength="35" >
        </div>

        <div class="form-group mb-3">
            <label for="">Author <span style="color:#F00;">*</span></label>
            <input type="text" name="author" class="form-control" id="author" placeholder="Enter book author" onKeyUp="this.value = this.value.toUpperCase()" autocomplete="off" maxlength="30">
        </div>

        <div class="form-group mb-3">
            <label for="">Genre</label>
            <input type="text" name="genre" class="form-control" id="genre" placeholder="Enter book genre" onKeyUp="this.value = this.value.toUpperCase()" autocomplete="off" maxlength="30">
        </div>

  
        <div class="form-group mb-3">
        <label class="year">Publication Year <span style="color:#F00;">Please enter a valid year between 1500 and the current year.</span></label>
          <input type="number" name="publication_year" id="publication_year" class="form-control"
          placeholder="Enter publication year" min="1500" max="2099" required>
          <div class="invalid-feedback">Please enter a valid year between 1500 and the current year.</div>
        </div>
          
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
        <button type="submit" name="update_book" class="btn btn-warning">Update</button>
      </div>
      </form>
    </div>
  </div>
</div>
<!-- Update  Book data Modal-->


<!-- Delete Book data Modal -->
<div class="modal fade" id="delete_book_modal" tabindex="-1" aria-labelledby="delete_book_modalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="delete_book_modalLabel">Delete Book Details :</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form>
      <input type="hidden" name="id" value="<?php echo $_POST['id'];?>" />
      <div class="modal-body">
       <h4> <p>Are you sure you want to delete this record...!</p></h4>
      </div>
      <div class="modal-footer">
      <button type="button" class="btn btn-default" data-bs-dismiss="modal">Close</button>
      <button type="submit" class="btn btn-danger" name="submit"><i class="fa fa-trash"></i> Yes ! Delete</button>
      </div>
      </form>
    </div>
  </div>
</div>
<!-- Delete Book data Modal -->


<div class="container mt-5">
  <div class="row justify-content-center">
    <div class="col-md-12">
<!-- SESSION MESSAGE -->
      <?php if($_SESSION['action'] != NULL && $_SESSION['status'] != NULL) { ?>
      <div class="alert 
          <?php if($_SESSION['status'] == 'success') { ?>alert-success<?php } else if($_SESSION['status'] == 'error') { ?>alert-danger<?php } else { ?>alert-warning<?php } ?>
          alert-dismissible fade show" role="alert">
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        <h4 class="alert-heading">
          <?php if($_SESSION['status'] == 'success') { ?><i class="icon fa fa-check"></i><?php } else { ?><i class="icon fa fa-exclamation-triangle"></i><?php } ?>
          <?php if($_SESSION['status'] == 'success') { ?>Success<?php } else if($_SESSION['status'] == 'error') { ?>Error!<?php } else { ?>Alert<?php } ?>
        </h4>
        <?php echo $_SESSION['action']; $_SESSION['action'] = NULL; ?>
      </div>
    <?php } ?>
  <!-- SESSION MESSAGE -->


      <div class="card">
        <div class="card-header">
          <h4 class="text-center"><strong>Manage Books List Application</strong></h4>
        <!-- Bootstrap Pop Modal -->
          <button type="button" title="add new book" class="btn btn-success float-end" data-bs-toggle="modal" data-bs-target="#insertBook">
          Add Book
          </button>
        <!-- Bootstrap Pop Modal -->
        </div>
        <div class="card-body">
    <table class="table table-striped border-dark">
        <thead>
            <tr>
                <th >Sr No.</th>
                <th>Book Title</th>
                <th>Author</th>
                <th>Genre</th>
                <th>Publish Year</th>
                <th>Created At</th>

                <th class="text-center">Action</th>
            </tr>
        </thead>
        <tbody>

            <?php 
            // Feth Data From Books Table
            $db = getDB();
            $sq = $db->prepare("SELECT * FROM books");
            $sq->execute(); 
            $rows = $sq->fetchAll();
            $NumRows = count($rows); 
            if($NumRows > 0) {
            foreach($rows as $row) {
            ?>
              <tr>
                  <td class="book_id"><?php echo $row['id']; ?></td>
                  <td><?php echo $row['title']; ?></td>
                  <td><?php echo $row['author']; ?></td>
                  <td><?php echo $row['genre']; ?></td>
                  <td><?php echo $row['publication_year']; ?></td>
                  <td><?php echo $row['created_at']; ?></td>
                  <td class="text-center">
                  <a href="javascript:void(0)" class="btn btn-info view_book" title="View Record">
                  <i class="fa fa-eye"></i>
                  </a>
                  <a href="javascript:void(0)" class="btn btn-warning update_book" title="Edit Record">
                  <i class="fa fa-edit"></i>
                  </a>
                  <a href="javascript:void(0)" class="btn btn-danger delete_book" title="Delete Record">
                  <i class="fa fa-trash"></i>
                  </a>
                  </td>
              </tr>
              <?php
                }
            } else {
                ?>
                <tr>
                    <td colspan="7">
                    <div class="table-responsive">
                        <div class="alert alert-danger" role="alert">
                            <i class="bi bi-exclamation-triangle"></i> No book available ..
                        </div>
                    </div>
                    </td>
                </tr>
                <?php
            }
            ?>
              </tbody>
          </table>
      </div>
      </div>
    </div>
  </div>
</div>

<?php include('includes/footer.php'); ?>
<!-- View Book Data -->
<script type="text/javascript">
  $(document).ready(function(){

    $('.view_book').click(function(e){
      e.preventDefault();
     var book_id= $(this).closest('tr').find('.book_id').text();
      //console.log(book_id);

      $.ajax({
        method:"POST",
        url:"code.php",
        data:{
          'click_view_btn': true,
          'book_id':book_id,

        },
        success:function(response){
          //console.log(response);

        $('.view_book_data').html(response);
        $('#view_book_modal').modal('show');
        }

      })

    });


  });


</script>
<!-- View Book Data -->

<!-- Update Book Data -->
<script type="text/javascript">
  $(document).ready(function(){

    $('.update_book').click(function(e){
      e.preventDefault();
     var book_id= $(this).closest('tr').find('.book_id').text();
      //console.log(book_id);

      $.ajax({
        method:"POST",
        url:"code.php",
        data:{
          'click_update_btn': true,
          'book_id':book_id,

        },
        success:function(response){
          //console.log(response);
          $.each(response, function(key , value){
            //console.log(value['title']);
            $('#id').val(value['id']);
            $('#title').val(value['title']);
            $('#author').val(value['author']);
            $('#genre').val(value['genre']);
            $('#publication_year').val(value['publication_year']);


          });
       
          $('#update_book_modal').modal('show');
        }

      })

    });


  });


</script>
<!-- Update Book Data -->

<!-- Delete Book Data -->
<script type="text/javascript">
  $(document).ready(function(){

    $('.delete_book').click(function(e){
      e.preventDefault();
     var book_id= $(this).closest('tr').find('.book_id').text();
      console.log(book_id);

      $.ajax({
        method:"POST",
        url:"code.php",
        data:{
          'click_delete_btn': true,
          'book_id':book_id,

        },
        success:function(response){
          //console.log(response);
          $('#delete_book_modal').modal('show');

        }

      })

    });


  });


</script>
<!-- Delete Book Data -->



 
<!--  Add Year-->
<script>
document.addEventListener('DOMContentLoaded', (event) => {
    const inputYear = document.getElementsByClassName('year');
    const currentYear = new Date().getFullYear();

    // Set max attribute dynamically to the current year
    inputYear.setAttribute('max', currentYear);

    inputYear.addEventListener('input', () => {
        const value = inputYear.value;
        const year = parseInt(value, 10);

        // Validate that year is a four-digit number within the range
        if (value.length === 4 && year >= 1500 && year <= currentYear) {
            inputYear.classList.remove('is-invalid');
            inputYear.setCustomValidity('');
        } else {
            inputYear.classList.add('is-invalid');
            inputYear.setCustomValidity('Please enter a valid year between 1500 and ' + currentYear + '.');
        }
    });
});
</script>

<!--  Add Year-->
