<?php 
include("db.php");
include("function.php");
$db = getDB();
$NowDateTime=date("Y-m-d H:i:s");
// Save Book Details
if(isset($_POST['save_book']))
{
  try 
  {	
	  if($_POST['title']!=NULL){$title= trim(strip_tags($_POST['title']));}else{$title='';}
      if($_POST['author']!=NULL){$author=trim(strip_tags($_POST['author']));}else{$author='';}
      if($_POST['genre']!=NULL){$genre=trim(strip_tags($_POST['genre']));}else{$genre='';}
      if($_POST['publication_year']!=NULL){$publication_year=intval($_POST['publication_year']);}else{$publication_year='';}

	  $stmt = $db->prepare("SELECT * FROM books WHERE title=:title"); 
	  $stmt->bindParam(":title", $title,PDO::PARAM_STR);
	  $stmt->execute();
	  $countRow=$stmt->rowCount();
	  
	 if($countRow>0)
	  {
		  $_SESSION['status']="error";
	      $_SESSION['action']="Book title name has been already taken !!!";
	      msg_redirect("".$_SESSION['action']."","index.php","0");
	      exit();	
	  }
      else if($_POST['title']=='' && $_POST['title']==NULL)
	  {
		  $_SESSION['status']="error";
		  $_SESSION['action']="Book title input field is required!";
		  msg_redirect("".$_SESSION['action']."","index.php","0");
		  exit();
	  }
      else if($_POST['author']=='' && $_POST['author']==NULL)
	  {
		  $_SESSION['status']="error";
		  $_SESSION['action']="Book author input field is required!";
		  msg_redirect("".$_SESSION['action']."","index.php","0");
		  exit();
	  }
	  else
	  {	
		  $stmt = $db->prepare("INSERT INTO books(title,author,genre,publication_year,created_at)VALUES(:title,:author,:genre,:publication_year,:created_at)");
		  $stmt->bindParam(":title", $title,PDO::PARAM_STR);
          $stmt->bindParam(":author", $author,PDO::PARAM_STR);
          $stmt->bindValue(':genre', !empty($genre) ? $genre : NULL, PDO::PARAM_STR);
          $stmt->bindValue(':publication_year', !empty($publication_year) ? $publication_year : NULL, PDO::PARAM_INT);
          $stmt->bindParam(':created_at', $NowDateTime,PDO::PARAM_STR);
		  $stmt->execute();
		  $count=$stmt->rowCount();
		  if($count>0)
		  {
			 $_SESSION['status']="success";
			 $_SESSION['action']="Book details has been added successfully.";
	         msg_redirect("".$_SESSION['action']."","index.php","0");
	         exit();
		  }
	  }
  }
  catch (PDOException $e) 
  {
    $error = $e->getMessage ();
	$_SESSION['status']="error";
	$_SESSION['action']="The server encountered an error processing your request!";
	msg_redirect("".$_SESSION['action']."","index.php","0");
	exit();
   }
}
// Save Book Details

// Show Book Details
if (isset($_POST['click_view_btn'])) {
    $id = $_POST['book_id'];
    $db = getDB();
    try
	 {
        $sq = $db->prepare("SELECT * FROM books WHERE id = :id");
        $sq->bindParam(':id', $id, PDO::PARAM_INT);
        $sq->execute();
        // Fetch the results
        $row = $sq->fetch(PDO::FETCH_ASSOC);
        if ($row) {
            echo '
                <h6> Book Title  :  ' .($row['title']) . '</h6>
                <h6> Book Author :  ' .($row['author']) . '</h6>
                <h6> Book Genre  :  ' .($row['genre']) . '</h6>
                <h6>Public Year  :  ' .($row['publication_year']) . '</h6>
            ';
        } else {
            echo "<h4>No record found</h4>";
        }
    } catch (PDOException $e) {
        echo "<h4>Error: " . htmlspecialchars($e->getMessage()) . "</h4>";
    }
}
// Show Book Details

// Fetch data in Update Form
if (isset($_POST['click_update_btn'])) {
    $id = $_POST['book_id'];
	$arrayresult=[];
    $db = getDB();
    try
	 {
        $sq = $db->prepare("SELECT * FROM books WHERE id= :id");
        $sq->bindParam(':id', $id, PDO::PARAM_INT);
        $sq->execute();
        // Fetch the results
        $row = $sq->fetch(PDO::FETCH_ASSOC);
        if ($row) {
		array_push($arrayresult,$row);
		header('content-type:application/json');
		echo json_encode($arrayresult);
        } 
		else 
		{
            echo "<h4>No record found</h4>";
        }
    } catch (PDOException $e) {
        echo "<h4>Error: " . htmlspecialchars($e->getMessage()) . "</h4>";
    }
}
// Fetch data in Update Form


// Update Book Details

if(isset($_POST['update_book']))
{
  try 
  {	

	$id=intval($_POST['id']);
	  if($_POST['title']!=NULL){$title= trim(strip_tags($_POST['title']));}else{$title='';}
      if($_POST['author']!=NULL){$author=trim(strip_tags($_POST['author']));}else{$author='';}
      if($_POST['genre']!=NULL){$genre=trim(strip_tags($_POST['genre']));}else{$genre='';}
      if($_POST['publication_year']!=NULL){$publication_year=intval($_POST['publication_year']);}else{$publication_year='';}

	  $stmt = $db->prepare("SELECT * FROM books WHERE title=:title AND id!=:id"); 
	  $stmt->bindParam(":title", $title,PDO::PARAM_STR);
	  $stmt->bindParam(':id', $id, PDO::PARAM_INT);
	  $stmt->execute();
	  $countRows=$stmt->rowCount();
	  
	 if($countRows>0)
	  {
		  $_SESSION['status']="error";
	      $_SESSION['action']="Book title name has been already taken !!!";
	      msg_redirect("".$_SESSION['action']."","index.php","0");
	      exit();	
	  }
      else if($_POST['title']=='' && $_POST['title']==NULL)
	  {
		  $_SESSION['status']="error";
		  $_SESSION['action']="Book title input field is required!";
		  msg_redirect("".$_SESSION['action']."","index.php","0");
		  exit();
	  }
      else if($_POST['author']=='' && $_POST['author']==NULL)
	  {
		  $_SESSION['status']="error";
		  $_SESSION['action']="Book author input field is required!";
		  msg_redirect("".$_SESSION['action']."","index.php","0");
		  exit();
	  }
	  else
	  {	
	
			$stmt = $db->prepare("UPDATE books SET title = :title, author = :author, genre = :genre, publication_year = :publication_year, updated_at = :updated_at WHERE id = :id");


			$stmt->bindParam(":title", $title, PDO::PARAM_STR);
			$stmt->bindParam(":author", $author, PDO::PARAM_STR);
			$stmt->bindValue(':genre', !empty($genre) ? $genre : null, PDO::PARAM_STR);
			$stmt->bindValue(':publication_year', !empty($publication_year) ? $publication_year : null, PDO::PARAM_INT);
			$stmt->bindParam(':updated_at', $NowDateTime, PDO::PARAM_STR);
			$stmt->bindParam(':id', $id, PDO::PARAM_INT);
			$stmt->execute();
			$count = $stmt->rowCount();

		if ($count > 0) {
		$_SESSION['status'] = "success";
		$_SESSION['action'] = "Book details have been updated successfully.";
		msg_redirect($_SESSION['action'], "index.php", "0");
		exit();
		} 
		else 
		{

		$error = $e->getMessage ();
		$_SESSION['status']="error";
		$_SESSION['action']="The server encountered an error processing your request!";
		msg_redirect("".$_SESSION['action']."","index.php","0");
		exit();
		}

	}
  }
  catch (PDOException $e) 
  {
    $error = $e->getMessage ();
	$_SESSION['status']="error";
	$_SESSION['action']="The server encountered an error processing your request!";
	msg_redirect("".$_SESSION['action']."","index.php","0");
	exit();
   }
}
// Update Book Details


// Delete Book Details
if (isset($_POST['click_delete_btn'])) {
    $id = $_POST['book_id'];
 try
 { 
	$stmt = $db->prepare("delete from books WHERE id= :id");
	$stmt->bindParam(':id', $id, PDO::PARAM_INT); 
	$stmt->execute();
	$count=$stmt->rowCount();
	if($count>0)
	{
	   $_SESSION['status']="success";
	   $_SESSION['action']="Book Details has been deleted successfully.";
	   msg_redirect("".$_SESSION['action']."","index.php","0");
	   exit();
	}
  }
  catch(PDOException $e) 
  {
	  $error = $e->getMessage();
	  $_SESSION['status']="warning";
	  $_SESSION['action']="The server encountered an error processing your request!";
	  msg_redirect("".$_SESSION['action']."","index.php","0");
	exit();
  } 	
}
// Delete Book Details


?>
