<?php 
function getDB() 
{
  $dbhost=DB_SERVER;
  $dbuser=DB_USERNAME;
  $dbpass=DB_PASSWORD;
  $dbname=DB_DATABASE;
  try 
  {
	$dbConnection = new PDO("mysql:host=$dbhost;dbname=$dbname;", $dbuser, $dbpass); 
	$dbConnection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$dbConnection->query('SET NAMES utf8');
	return $dbConnection;
  }
  catch (PDOException $e) 
  {
	echo 'Connection Failed';
  }
}


function msg_redirect($msg,$url,$seconds)
{
   echo "<meta http-equiv=\"Refresh\" content=\"$seconds; URL=$url\">\n";
}

?>